#!/usr/bin/env python
# -*- coding: utf-8 -*-


class Simulador():
    def simular(self):
        raise NotImplementedError()
