#!/usr/bin/env python
# -*- coding: utf-8 -*-


class Logger():
    def info(self, mensaje):
        print mensaje
